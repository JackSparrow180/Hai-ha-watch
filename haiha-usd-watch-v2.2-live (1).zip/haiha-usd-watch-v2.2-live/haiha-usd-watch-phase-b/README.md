# Hai Ha USD Watch — Phase B (v2.1)

Ứng dụng PWA mobile-first để theo dõi trường hợp **khách hàng bán USD cho Hai Ha và nhận AUD**.

## Nguyên tắc an toàn dữ liệu tỷ giá

- Auto Check chỉ chấp nhận dữ liệu khi backend xác minh đầy đủ:
  - `provider = HAI_HA`
  - `fromCurrency = USD`
  - `toCurrency = AUD`
  - `customerAction = SELL`
  - `mode = CUSTOMER_SELLS_USD`
  - `verified = true`
- Backend chỉ chấp nhận báo giá trực tiếp dạng `1 USD = X AUD` sau khi xác minh control **You sell / Bạn bán** đang ở trạng thái active/selected/checked.
- Không đảo `1 AUD = X USD` thành `1 / X`, vì buy/sell spread có thể khiến kết quả sai chiều giao dịch.
- Nếu Hai Ha bảo trì, thay đổi DOM, timeout hoặc không xác minh được hướng giao dịch, app **không ghi tỷ giá tự động** và giữ manual fallback.

## Kiến trúc

- `index.html`: giao diện
- `app.js`: state, localStorage, calculator, chart, target, Auto Check
- `sw.js`: PWA/offline app shell; `/api/` và Hai Ha là network-only
- `api/haiha-rate.js`: Vercel Function chạy Puppeteer/Chromium
- `lib/haiha-parser.js`: parser tỷ giá trực tiếp USD → AUD
- `tests/phase-b.test.mjs`: test công thức và parser
- `vercel.json`: `maxDuration` 30 giây cho function

## Node / Chromium / Puppeteer

Project pin:

- Node.js `24.x`
- `@sparticuz/chromium` `149.0.0`
- `puppeteer-core` `25.1.0`

Lý do: Puppeteer v25.1.0 được tài liệu Puppeteer liệt kê với Chrome milestone 149, phù hợp với Chromium 149. `@sparticuz/chromium` 149 hiện yêu cầu Node `^22.17.0 || >=24.0.0`, nên Node 24.x là lựa chọn phù hợp trên Vercel hiện tại.

> Lưu ý: compatibility production vẫn phải xác nhận bằng deploy thật vì serverless Chromium phụ thuộc runtime/bundle/memory của host.

## Chạy test

```bash
npm test
npm run check
```

## Chạy local

Frontend tĩnh có thể chạy bằng bất kỳ static server nào. Tuy nhiên endpoint `/api/haiha-rate` cần môi trường Vercel Functions hoặc `vercel dev`.

```bash
npm install
npx vercel dev
```

Sau đó mở URL local mà Vercel CLI cung cấp.

## Deploy lên Vercel

1. Tạo GitHub repository.
2. Upload toàn bộ project này vào repository.
3. Đăng nhập Vercel.
4. Chọn **Add New → Project**.
5. Import repository.
6. Giữ Node.js 24.x (package.json đã khai báo `engines.node`).
7. Deploy.
8. Mở `/api/haiha-rate` để kiểm tra JSON.
9. Mở trang app, bấm **Kiểm tra tự động**.
10. Nếu Hai Ha đang bảo trì hoặc backend chưa xác minh SELL + USD → AUD, app sẽ báo lỗi và không lưu rate tự động.

`vercel.json` đặt `maxDuration: 30` cho `api/haiha-rate.js`. Vercel cho phép cấu hình maximum duration trong giới hạn của plan; nếu plan không chấp nhận giá trị này, giảm theo dashboard/giới hạn plan thay vì tăng tùy tiện.

## PWA / offline

- App shell local được cache.
- Live API (`/api/`) và domain Hai Ha **không được cache**.
- Chart.js và Google Fonts vẫn là external static resources. Service worker dùng network-first + cache fallback sau khi chúng đã tải thành công ít nhất một lần; chúng không nằm trong `cache.addAll()` để tránh một CDN outage làm install service worker thất bại.
- Nếu Chart.js chưa từng tải và thiết bị offline, app vẫn mở và calculator vẫn dùng được; phần chart sẽ hiện thông báo không tải được thư viện.

## localStorage migration

Storage key vẫn là:

```text
haihaUsdWatch:v1
```

Các entry cũ được giữ. Entry Auto cũ từ v2 nhưng thiếu metadata verification sẽ được đánh dấu `LEGACY_AUTO` và **không còn được coi là LIVE** cho tới khi Auto Check mới xác minh lại.

## Stale rate

- 6–24 giờ: cảnh báo tỷ giá đã cũ.
- Trên 24 giờ: cảnh báo mạnh hơn và yêu cầu kiểm tra lại Hai Ha trước giao dịch.

## Notification

Notification hiện tại là local browser notification. Nó chỉ kiểm tra khi app/JavaScript đang chạy. **Chưa có background monitoring 24/7.** Background cron + push notification thuộc Phase F, chưa triển khai.

## Environment variables

Hiện tại không cần environment variable. File `.env.example` chỉ ghi chú nguyên tắc không đặt secret vào frontend.

## Trạng thái Hai Ha lúc Phase B

Trang Foreign Exchange chính thức của Hai Ha đang hiển thị maintenance và rate 0 tại thời điểm kiểm tra Phase B. Vì vậy happy-path của Auto Check chưa thể xác minh production cho tới khi calculator hoạt động lại.
