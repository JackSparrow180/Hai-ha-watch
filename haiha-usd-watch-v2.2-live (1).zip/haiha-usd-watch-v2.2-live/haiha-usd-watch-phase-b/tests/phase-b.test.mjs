import test from "node:test";
import assert from "node:assert/strict";
import { isMaintenanceText, isRateSane, parseDirectUsdToAud } from "../lib/haiha-parser.js";

test("A: 50,000 USD at 1.5200 = 76,000 AUD", () => {
  assert.equal(50000 * 1.52, 76000);
});

test("B: previous 1.5100 to current 1.5200 = +500 AUD", () => {
  assert.ok(Math.abs(50000 * (1.52 - 1.51) - 500) < 1e-9);
});

test("C: current 1.5200 to target 1.5500 = +1,500 AUD", () => {
  assert.ok(Math.abs(50000 * (1.55 - 1.52) - 1500) < 1e-9);
});

test("Direct USD->AUD quote parses", () => {
  const parsed = parseDirectUsdToAud("You sell 1 USD = 1.5234 AUD");
  assert.equal(parsed?.rate, 1.5234);
  assert.equal(parsed?.fromCurrency, "USD");
  assert.equal(parsed?.toCurrency, "AUD");
});

test("D/E: reciprocal AUD->USD quote is rejected", () => {
  assert.equal(parseDirectUsdToAud("1 AUD = 0.6834 USD"), null);
});

test("F: maintenance text is detected", () => {
  assert.equal(isMaintenanceText("Our services are under maintenance. Please try later!"), true);
});

test("Zero and absurd rates are rejected", () => {
  assert.equal(isRateSane(0), false);
  assert.equal(isRateSane(8), false);
});
