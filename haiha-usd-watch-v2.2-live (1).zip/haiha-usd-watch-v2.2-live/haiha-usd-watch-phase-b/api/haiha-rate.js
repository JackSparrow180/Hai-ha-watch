import puppeteer from "puppeteer-core";
import chromium from "@sparticuz/chromium";
import {
  isMaintenanceText,
  isRateSane,
  parseDirectUsdToAud,
} from "../lib/haiha-parser.js";

const CALCULATOR_URL = "https://app.hhmt.com.au/fx-calculator-form?lang=en";
const NAVIGATION_TIMEOUT_MS = 15000;
const ACTION_TIMEOUT_MS = 6000;

class HaiHaRateError extends Error {
  constructor(status, message, httpStatus = 503) {
    super(message);
    this.name = "HaiHaRateError";
    this.status = status;
    this.httpStatus = httpStatus;
  }
}

function log(step, detail = "") {
  const suffix = detail ? ` · ${detail}` : "";
  console.log(`[HaiHa] ${step}${suffix}`);
}

async function bodyText(page) {
  return page.evaluate(() => document.body?.innerText || "");
}

async function describeSellControl(handle) {
  return handle.evaluate((el) => {
    const className = typeof el.className === "string" ? el.className : "";
    const parentClass = typeof el.parentElement?.className === "string" ? el.parentElement.className : "";
    const input = el.matches?.("input") ? el : el.querySelector?.("input");
    return {
      text: (el.textContent || el.getAttribute?.("aria-label") || "").trim(),
      ariaSelected: el.getAttribute?.("aria-selected") || "",
      ariaPressed: el.getAttribute?.("aria-pressed") || "",
      ariaChecked: el.getAttribute?.("aria-checked") || "",
      dataState: el.getAttribute?.("data-state") || "",
      className,
      parentClass,
      checked: Boolean(input?.checked),
    };
  });
}

function looksActive(state) {
  if (!state) return false;
  if ([state.ariaSelected, state.ariaPressed, state.ariaChecked].some((v) => String(v).toLowerCase() === "true")) return true;
  if (/active|selected|current|checked|on/i.test(state.dataState || "")) return true;
  if (/\b(active|selected|current|checked|on)\b/i.test(`${state.className || ""} ${state.parentClass || ""}`)) return true;
  return Boolean(state.checked);
}

async function findSellControls(page) {
  const handles = await page.$$("button,[role='tab'],[role='button'],a,label,input[type='radio']");
  const matches = [];
  for (const handle of handles) {
    const state = await describeSellControl(handle).catch(() => null);
    if (!state) continue;
    if (/^(you\s*sell|sell|bạn\s*bán|ban\s*ban)$/i.test(state.text)) {
      matches.push({ handle, state });
    }
  }
  return matches;
}

async function verifySellMode(page) {
  const controls = await findSellControls(page);
  for (const item of controls) {
    const state = await describeSellControl(item.handle).catch(() => null);
    if (looksActive(state)) return true;
  }
  return false;
}

async function activateAndVerifySellMode(page) {
  const controls = await findSellControls(page);
  if (!controls.length) {
    throw new HaiHaRateError("SELL_BUTTON_NOT_FOUND", "Không tìm thấy nút 'You sell/Bạn bán' trên calculator Hai Ha.");
  }

  // If the calculator already opens in sell mode, accept only if the control exposes
  // an explicit selected/active/checked state.
  if (controls.some((item) => looksActive(item.state))) {
    log("SELL_MODE_VERIFIED", "already active");
    return;
  }

  let clickWorked = false;
  for (const item of controls) {
    try {
      await item.handle.click();
      clickWorked = true;
      log("SELL_CONTROL_CLICKED");
      break;
    } catch (error) {
      log("SELL_CLICK_FAILED", error?.message || "unknown click error");
    }
  }

  if (!clickWorked) {
    throw new HaiHaRateError("SELL_CLICK_FAILED", "Không thể chuyển calculator Hai Ha sang chế độ 'You sell/Bạn bán'.");
  }

  await new Promise((resolve) => setTimeout(resolve, 900));
  const verified = await verifySellMode(page);
  if (!verified) {
    throw new HaiHaRateError(
      "SELL_MODE_NOT_VERIFIED",
      "Đã bấm 'You sell/Bạn bán' nhưng không xác minh được calculator thực sự ở chế độ bán."
    );
  }
  log("SELL_MODE_VERIFIED");
}

function classifyError(error) {
  if (error instanceof HaiHaRateError) return error;
  const message = error?.message || "Không thể đọc tỷ giá Hai Ha.";
  if (/timeout/i.test(message)) {
    return new HaiHaRateError("BROWSER_TIMEOUT", "Calculator Hai Ha phản hồi quá chậm hoặc browser bị timeout.");
  }
  return new HaiHaRateError("BROWSER_ERROR", "Không thể đọc calculator Hai Ha tự động.");
}

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store, max-age=0, must-revalidate");
  if (req.method !== "GET") {
    return res.status(405).json({ ok: false, status: "METHOD_NOT_ALLOWED", message: "GET only" });
  }

  let browser;
  try {
    log("START");
    chromium.setGraphicsMode = false;
    browser = await puppeteer.launch({
      args: await puppeteer.defaultArgs({ args: chromium.args, headless: "shell" }),
      executablePath: await chromium.executablePath(),
      headless: "shell",
      defaultViewport: { width: 390, height: 844, deviceScaleFactor: 1 },
    });
    log("BROWSER_LAUNCHED");

    const page = await browser.newPage();
    page.setDefaultNavigationTimeout(NAVIGATION_TIMEOUT_MS);
    page.setDefaultTimeout(ACTION_TIMEOUT_MS);

    await page.goto(CALCULATOR_URL, { waitUntil: "domcontentloaded" });
    log("PAGE_LOADED");

    // Give the JS app a short, bounded window to render.
    await new Promise((resolve) => setTimeout(resolve, 1200));
    let text = await bodyText(page);

    if (isMaintenanceText(text)) {
      throw new HaiHaRateError("HAIHA_MAINTENANCE", "Calculator Hai Ha đang bảo trì hoặc chưa trả dữ liệu.");
    }
    log("MAINTENANCE_CHECK", "clear");

    await activateAndVerifySellMode(page);

    text = await bodyText(page);
    if (isMaintenanceText(text)) {
      throw new HaiHaRateError("HAIHA_MAINTENANCE", "Calculator Hai Ha đang bảo trì hoặc chưa trả dữ liệu.");
    }

    const parsed = parseDirectUsdToAud(text);
    if (!parsed) {
      // Deliberately reject reciprocal/inverted quotes. A buy quote cannot safely be
      // converted into the customer-sells-USD quote by taking 1/x.
      throw new HaiHaRateError(
        "USD_AUD_DIRECTION_NOT_VERIFIED",
        "Không tìm thấy báo giá trực tiếp '1 USD = X AUD' sau khi xác minh chế độ bán."
      );
    }
    log("USD_DIRECTION_VERIFIED", parsed.quote);

    if (!isRateSane(parsed.rate)) {
      throw new HaiHaRateError("RATE_INVALID", "Tỷ giá Hai Ha đọc được nằm ngoài phạm vi kiểm tra an toàn.");
    }
    log("RATE_VALIDATED", String(parsed.rate));

    return res.status(200).json({
      ok: true,
      status: "VERIFIED",
      provider: "HAI_HA",
      fromCurrency: "USD",
      toCurrency: "AUD",
      customerAction: "SELL",
      mode: "CUSTOMER_SELLS_USD",
      verified: true,
      rate: Number(parsed.rate.toFixed(6)),
      quotedText: parsed.quote,
      fetchedAt: new Date().toISOString(),
      source: "Hai Ha Foreign Exchange Calculator",
      sourceUrl: CALCULATOR_URL,
    });
  } catch (rawError) {
    const error = classifyError(rawError);
    log(error.status, rawError?.message || error.message);
    return res.status(error.httpStatus || 503).json({
      ok: false,
      status: error.status,
      provider: "HAI_HA",
      fromCurrency: "USD",
      toCurrency: "AUD",
      customerAction: "SELL",
      mode: "CUSTOMER_SELLS_USD",
      verified: false,
      message: error.message,
      fetchedAt: new Date().toISOString(),
    });
  } finally {
    if (browser) {
      try {
        await browser.close();
        log("BROWSER_CLOSED");
      } catch (error) {
        log("BROWSER_CLOSE_FAILED", error?.message || "unknown close error");
      }
    }
  }
}
