import test from "node:test";
import assert from "node:assert/strict";
import {
  deriveUsdToAudRate,
  isMaintenanceText,
  isRateSane,
  parseDirectUsdToAud,
  parseMoneyNumber,
} from "../lib/haiha-parser.js";

test("A: 50,000 USD at 1.5200 = 76,000 AUD", () => {
  assert.equal(50000 * 1.52, 76000);
});

test("B: previous 1.5100 to current 1.5200 = +500 AUD", () => {
  assert.ok(Math.abs(50000 * (1.52 - 1.51) - 500) < 1e-9);
});

test("C: current 1.5200 to target 1.5500 = +1,500 AUD", () => {
  assert.ok(Math.abs(50000 * (1.55 - 1.52) - 1500) < 1e-9);
});

test("Hai Ha screenshot example: sell 1,500 USD, receive 2,051.70 AUD => 1 USD = 1.3678 AUD", () => {
  const q = deriveUsdToAudRate("1,500", "2,051.70");
  assert.equal(q?.rate, 1.3678);
  assert.equal(q?.soldUsd, 1500);
  assert.equal(q?.receivedAud, 2051.70);
  assert.equal(q?.quoteMethod, "SELL_OUTPUT_DIVIDED_BY_INPUT");
});

test("Formatted calculator numbers parse", () => {
  assert.equal(parseMoneyNumber("2,051.70"), 2051.7);
  assert.equal(parseMoneyNumber("1,500"), 1500);
});

test("Direct USD->AUD headline can still parse for diagnostics", () => {
  const parsed = parseDirectUsdToAud("You sell 1 USD = 1.5234 AUD");
  assert.equal(parsed?.rate, 1.5234);
});

test("AUD->USD headline is not used as a direct USD->AUD quote", () => {
  assert.equal(parseDirectUsdToAud("1 AUD = 0.7311 USD"), null);
});

test("Maintenance text is detected", () => {
  assert.equal(isMaintenanceText("Our services are under maintenance. Please try later!"), true);
});

test("Zero and absurd rates are rejected", () => {
  assert.equal(isRateSane(0), false);
  assert.equal(isRateSane(8), false);
});
